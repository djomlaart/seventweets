from setuptools import setup, find_packages

setup(
    name='7tweets',
    version='0.1.0',
    description='example python flask service',
    platforms=['POSIX', 'MacOS'],
    url='https://github.com/zvrbaski/7tweets',
    packages=find_packages(),
)
