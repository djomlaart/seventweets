# 7tweets
Example code for python workshop
