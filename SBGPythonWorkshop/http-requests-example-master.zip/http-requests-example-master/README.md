# http-requests-example
Example code for requests, flask and pytest
