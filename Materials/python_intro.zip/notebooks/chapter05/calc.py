"""
Documentation for calc module
"""

def average(list):
    """Function for calculating the average value!"""
    return float(sum(list)) / len(list)