#!/bin/sh -x

#// START OMIT
docker build -t janos/radionica-primer2 primer2
#// END OMIT