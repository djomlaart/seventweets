#!/bin/sh -x

#// START OMIT
docker stop primer2
#// END OMIT