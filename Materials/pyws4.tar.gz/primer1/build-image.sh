#!/bin/sh -x

#// START OMIT
docker build -t janos/radionica-primer1 primer1
#// END OMIT