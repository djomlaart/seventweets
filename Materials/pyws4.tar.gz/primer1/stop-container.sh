#!/bin/sh -x

#// START OMIT
docker stop primer1
#// END OMIT