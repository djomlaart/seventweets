#!/bin/sh -x

#// START OMIT
docker ps -a
#// END OMIT