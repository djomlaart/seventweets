#!/bin/sh -x

#// START OMIT
docker diff radionica-postgres
#// END OMIT