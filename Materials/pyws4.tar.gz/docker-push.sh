#!/bin/sh -x

#// START OMIT
docker push janos/radionica-primer2
#// END OMIT