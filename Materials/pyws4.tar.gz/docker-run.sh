#!/bin/sh -x

#// START OMIT
docker run python:3 python --version
#// END OMIT