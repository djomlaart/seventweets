#!/bin/sh -x

#// START OMIT
docker logs radionica-postgres
#// END OMIT