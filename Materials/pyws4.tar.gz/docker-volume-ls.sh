#!/bin/sh -x

#// START OMIT
docker volume ls
#// END OMIT