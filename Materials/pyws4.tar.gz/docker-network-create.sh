#!/bin/sh -x

#// START OMIT
docker network create radionica
#// END OMIT
