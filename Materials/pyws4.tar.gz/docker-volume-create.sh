#!/bin/sh -x

#// START OMIT
docker volume create radionica-postgres-data
#// END OMIT