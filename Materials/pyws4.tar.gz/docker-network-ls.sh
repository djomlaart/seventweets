#!/bin/sh -x

#// START OMIT
docker network ls
#// END OMIT
